# Copyright 2018 Google LLC
"""An example DAG demonstrating Kubernetes Pod Operator."""

# [START composer_kubernetespodoperator_airflow_1]
import datetime

from airflow import models
#from airflow.contrib.kubernetes import secret
from airflow.contrib.operators import kubernetes_pod_operator

YESTERDAY = datetime.datetime.now() - datetime.timedelta(days=1)

# [START composer_kubernetespodoperator_minconfig_airflow_1]
def crtK8sPodOperator(jobId):
    return kubernetes_pod_operator.KubernetesPodOperator(
        task_id=jobId,
        name=jobId,
        cmds=['java'],
        arguments=['-jar', 's3batch.jar', jobId],
        namespace='default',
        image='gcr.io/newageprj/s3batch:latest')
# [END composer_kubernetespodoperator_minconfig_airflow_1]

with models.DAG(
        dag_id='s3batch_k8s_gcs_pod_1',
        schedule_interval=datetime.timedelta(days=1),
        start_date=YESTERDAY) as dag:
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc152d = crtK8sPodOperator('semc152d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc153d = crtK8sPodOperator('semc153d')
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    semc152d >> semc153d 
# [END composer_kubernetespodoperator_airflow_1]
