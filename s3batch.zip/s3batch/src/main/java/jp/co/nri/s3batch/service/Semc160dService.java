package jp.co.nri.s3batch.service;

import jp.co.nri.s3batch.common.FioHelper;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;

@Component
public class Semc160dService extends BatchService {

    public Semc160dService() {
        super("###Semc160d service###");
    }
    public Semc160dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc160dService started...name:[" + name + "]");
        try {
            // sys010
            FioHelper sys010FH = getFioHelper("SYS010");
            FioHelper sys011FH = getFioHelper("SYS011");
            FioHelper sys020FH = getFioHelper("SYS020");
            FioHelper sys021FH = getFioHelper("SYS021");
            InputStream sys010IS = sys010FH.inStrm;
            InputStream sys011IS = sys011FH.inStrm;
            OutputStream sys020OS = sys020FH.outStrm;
            OutputStream sys021OS = sys021FH.outStrm;

            BufferedReader br = new BufferedReader(new InputStreamReader(sys010IS));
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(sys020OS));
            String line = "";
            disp("Result of resource:[" + sys010FH.fioUrl + "] start....");
            disp("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
            while ((line = br.readLine()) != null) {
                bw.write("From sys010:[" + line + "]");
                bw.newLine();
                disp(line);
            }
            disp("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑");
            br.close();
            bw.close();
        } catch (IOException ex) {
           disp("Semc160dService failed.Exception:[" + ex + "]");
        }
        disp("Semc160dService finished...name:[" + name + "]");
        // 処理正常終了
    }
}
