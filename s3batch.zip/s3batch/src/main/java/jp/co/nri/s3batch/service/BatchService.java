package jp.co.nri.s3batch.service;

import jp.co.nri.s3batch.common.BatchCommon;
import jp.co.nri.s3batch.common.FioHelper;
import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.springframework.context.ConfigurableApplicationContext;
import java.io.InputStream;
import java.io.OutputStream;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;

abstract public class BatchService extends BatchCommon {

    protected String name;
    protected Map<String, FioHelper> fioHelperMap;

    public BatchService(String name) {
        this.name = name;
        fioHelperMap = new HashMap<String, FioHelper>();
    }
    abstract public void startProc();

    @Override
    public String toString() {
        return "BatchService [name=" + name + "]";
    }

	public void setupIOProc(ConfigurableApplicationContext ctx, Map<String, String> sysEnvVars) {
        String fioName, fioUrl, fioAccess;
        String[] arrStr;
        FioHelper fioHelper;
        // get file input-output variables from system environments
        for(Map.Entry<String, String> entry : sysEnvVars.entrySet()) {
			if (entry.getKey().startsWith("FIO-")) {
                fioName = entry.getKey().substring(4);
                arrStr = entry.getValue().split("@");
                if (arrStr.length >= 2) {
                    fioUrl = arrStr[0];    
                    fioAccess = arrStr[1].toUpperCase();    
                } else {
                    fioUrl = arrStr[0];    
                    fioAccess = "RO";    
                }
                disp("FIO:[" + fioName + "],[" + fioUrl + "],[" + fioAccess + "]");
                switch(fioAccess) {
                    case "RO":
                        fioHelper = new FioHelper(ctx, fioName, fioUrl, fioAccess);
                        fioHelperMap.put(fioName, fioHelper);
                        break;
                    case "WO":
                        fioHelper = new FioHelper(ctx, fioName, fioUrl, fioAccess);
                        fioHelperMap.put(fioName, fioHelper);
                        break;
                    default:
                        disp("Invalid access mode:[" + fioName + "],[" + fioUrl + "][" + fioAccess + "]");
                        break;
                }
			}
        }
	}
    FioHelper getFioHelper(String fioName) {
        return fioHelperMap.get(fioName);
    }
    InputStream getInputStream(String fioName) {
        return fioHelperMap.get(fioName).inStrm;
    }
    OutputStream getOutputStream(String fioName) {
        return fioHelperMap.get(fioName).outStrm;
    }
}
