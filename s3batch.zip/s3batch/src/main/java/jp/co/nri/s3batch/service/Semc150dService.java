package jp.co.nri.s3batch.service;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Semc150dService extends BatchService {

    private String convertStringToHex(String str) {
        StringBuilder stringBuilder = new StringBuilder();
        char[] charArray = str.toCharArray();
        for (char c : charArray) {
            String charToHex = Integer.toHexString(c);
            stringBuilder.append(charToHex);
        }
        return(stringBuilder.toString());
    }
    public Semc150dService(String name) {
        super(name);
    }
    public void startProc() {
        String fileName = "/var/secrets/good1.txt";
        disp("Semc150dService started...name:[" + name + "]");
        try {
            disp("File name:[" + fileName + "],hex:[" + convertStringToHex(fileName) + "]");
            File file = new File(fileName);
            BufferedReader br = new BufferedReader(new FileReader(file));
            String str = br.readLine();
            while(str != null){
                disp("input line:" + str + "]");
                str = br.readLine();
            }
            br.close();
        }catch(FileNotFoundException e){
            disp("FileNotFoundException:[" + e + "]");
        }catch(IOException e){
            disp("IOException:[" + e + "]");
        }
        disp("Semc150dService finished...name:[" + name + "]");
    }
}
