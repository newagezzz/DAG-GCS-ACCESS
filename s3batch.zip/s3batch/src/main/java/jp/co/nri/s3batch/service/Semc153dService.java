package jp.co.nri.s3batch.service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.core.io.Resource;
//import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

public class Semc153dService extends BatchService {

    public Semc153dService() {
        super("###Semc153d service###");
    }
    public Semc153dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc153dService started...name:[" + name + "]");
        try {
            // mntfile
            File MntFIle = new File("/home/airflow/gcs/data/test_file");
            String msg = MntFIle.exists() ? "the MntFile is ready" : "the MntFile is not exist";
            disp("↓↓↓↓↓↓↓↓↓↓↓mnt file↓↓↓↓↓↓↓↓↓↓↓↓");
            disp(msg);
            disp("↑↑↑↑↑↑↑↑↑↑↑mnt file↑↑↑↑↑↑↑↑↑↑↑");
        } catch (Exception ex) {
           disp("Semc161dService failed.Exception:[" + ex + "]");
        }
        disp("Semc153dService finished...name:[" + name + "]");
    }

}
