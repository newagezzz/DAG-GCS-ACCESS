package jp.co.nri.s3batch.common;

import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.lang.Runtime;
import java.lang.Process;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

public class BatchCommon {
    public BatchCommon() {
        //do nothing
    }
	protected static void disp(String msg) {
        // 現在日時を取得
        LocalDateTime nowDate = LocalDateTime.now();
		System.out.println(nowDate + ":[" + msg + "]");
	}

	protected static void doCommand(String sysCmds) {
        
        disp("commands to be executed:[" + sysCmds + "].");
        try {
            String[] arrCmd = sysCmds.split("#EOC!");
            Runtime r = Runtime.getRuntime();
            for (String cmd: arrCmd) {
                if (cmd.length() > 0) {
                    Process p = r.exec(cmd);
                    p.waitFor();
                    BufferedReader b = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String line = "";
                    disp("Result of command:[" + cmd + "] start....");
                    disp("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
                    while ((line = b.readLine()) != null) {
                        disp(line);
                    }
                    disp("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑");
                    b.close();
                    disp("Result of command:[" + cmd + "] finished....");
                }
            }
        } catch (Exception ex) {
            disp("BatchCommand.doCommand("+ sysCmds + ") failed. Exception:[" + ex + "]");
        }
    }
	protected static void getAllPaths(String rootPath) {
        disp("Getting all paths/files of [" + rootPath + "] start....");
        disp("↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓");
        try(Stream<Path> stream = Files.walk(Paths.get(rootPath))){
            stream.forEach(System.out::println);
        }catch(IOException e) {
            e.printStackTrace();
        }
        disp("↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑");
    }
}
