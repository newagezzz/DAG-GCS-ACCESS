package jp.co.nri.s3batch.service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.charset.Charset;

public class Semc151dService extends BatchService {

    public Semc151dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc151dService started...name:[" + name + "]");
        try {
            // ファイルのエンコーディングを指定する場合(Charset)
            Path file = Paths.get("d:\\work\\temp\\good1.txt");
            disp("file information:[" + file.toString() + "]");
            String text = Files.readString(file, Charset.forName("MS932"));
            disp(file.toString() + ":[" + text + "]");
        } catch (Exception ex) {
            disp("Exceptions occurred:[" + ex + "]");
        }
        disp("Semc151dService finished...name:[" + name + "]");
    }

}
