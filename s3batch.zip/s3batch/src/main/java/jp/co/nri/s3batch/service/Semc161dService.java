package jp.co.nri.s3batch.service;

import org.springframework.stereotype.Service;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

@Service
public class Semc161dService extends BatchService {

    //File MntFile = new File("/home/airflow/gcs/data/test_file");
    @Value("/home/airflow/gcs/data/test_file")
    private String mntFileName;


    public Semc161dService() {
        super("###Semc161d service###");
    }
    public Semc161dService(String name) {
        super(name);
    }
    public void startProc() {
        disp("Semc161dService started...name:[" + name + "]");
        try {
            // mntFile
            File MntFile = new File(mntFileName);
            disp("↓↓↓↓↓↓↓↓↓↓↓mnt file↓↓↓↓↓↓↓↓↓↓↓↓");
            if (MntFile.exists()) {
                disp("The MntFile is ready!");
                disp("mntFile:" + StreamUtils.copyToString(
                    new FileInputStream(mntFileName),
                    Charset.defaultCharset()) + "\n");
            } else {
                disp("The MntFile not exist!");
            }
            disp("↑↑↑↑↑↑↑↑↑↑↑mnt file↑↑↑↑↑↑↑↑↑↑↑");
        } catch (Exception ex) {
           disp("Semc161dService failed.Exception:[" + ex + "]");
        }
        disp("Semc161dService finished...name:[" + name + "]");
    }
}
