package jp.co.nri.s3batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3batchApplicationTests {

	@Test
	void contextLoads() {
	}

}
