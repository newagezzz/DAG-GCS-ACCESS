# Copyright 2018 Google LLC
"""An example DAG demonstrating Kubernetes Pod Operator."""

# [START composer_kubernetespodoperator_airflow_1]
import datetime

from airflow import models
#from airflow.contrib.kubernetes import secret
from airflow.contrib.operators import kubernetes_pod_operator

YESTERDAY = datetime.datetime.now() - datetime.timedelta(days=1)

# [START composer_kubernetespodoperator_minconfig_airflow_1]
def crtK8sPodOperator(jobId, jobEnv, doCmd, rootDir):
    return kubernetes_pod_operator.KubernetesPodOperator(
        task_id=jobId,
        name=jobId,
        service_account_name='nacompenv-ksa',
        cmds=['java'],
        arguments=['-jar', 's3batch.jar', jobId, doCmd, rootDir],
        namespace='default',
        image='gcr.io/newageprj/s3batch:latest', 
        env_vars=jobEnv)
# [END composer_kubernetespodoperator_minconfig_airflow_1]

with models.DAG(
        dag_id='s3batch_k8s_gcs_pod',
        schedule_interval=datetime.timedelta(days=1),
        start_date=YESTERDAY) as dag:
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc152dEnv = {}
    semc152dEnv['FIO-SYS010'] = 'gs://newage-test-bucket/semc152d/sys010@ro'
    semc152dEnv['FIO-SYS011'] = 'gs://newage-test-bucket/semc152d/sys011@ro'
    semc152dEnv['FIO-SYS012'] = 'gs://newage-test-bucket/semc152d/sys012@ro'
    semc152dEnv['FIO-SYS020'] = 'gs://newage-test-bucket/semc152d/sys020@wo'
    semc152dEnv['FIO-SYS021'] = 'gs://newage-test-bucket/semc152d/sys021@wo'
    semc152dEnv['FIO-SYS022'] = 'gs://newage-test-bucket/semc152d/sys022@wo'
    semc152dCmd = "ls -l /"
    semc152d = crtK8sPodOperator('semc152d', semc152dEnv, semc152dCmd, "/home")
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc153dEnv = {}
    semc153dEnv['FIO-SYS010'] = 'gs://newage-test-bucket/semc153d/sys010@ro'
    semc153dEnv['FIO-SYS011'] = 'gs://newage-test-bucket/semc153d/sys011@ro'
    semc153dEnv['FIO-SYS012'] = 'gs://newage-test-bucket/semc153d/sys012@ro'
    semc153dEnv['FIO-SYS020'] = 'gs://newage-test-bucket/semc153d/sys020@wo'
    semc153dEnv['FIO-SYS021'] = 'gs://newage-test-bucket/semc153d/sys021@wo'
    semc153dEnv['FIO-SYS022'] = 'gs://newage-test-bucket/semc153d/sys022@wo'
    semc153dCmd = "ls -l /"
    semc153dCmd += "#EOC!" + "ls -l /home"
    semc153dCmd += "#EOC!" + "ls -l /home/airflow"
    semc153dCmd += "#EOC!" + "ls -l /home/airflow/gcs"
    semc153dCmd += "#EOC!" + "ls -l /home/airflow/gcs/data"
    semc153dCmd += "#EOC!" + "ls -l /home/airflow/gcs/data/test_file"
    semc153d = crtK8sPodOperator('semc153d', semc153dEnv, semc153dCmd, "/home")
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    # [START composer_kubernetespodoperator_minconfig_airflow_1]
    semc160dEnv = {}
    semc160dEnv['FIO-SYS010'] = 'gs://newage-test-bucket/semc160d/sys010@ro'
    semc160dEnv['FIO-SYS011'] = 'gs://newage-test-bucket/semc160d/sys011@ro'
    semc160dEnv['FIO-SYS012'] = 'gs://newage-test-bucket/semc160d/sys012@ro'
    semc160dEnv['FIO-SYS020'] = 'gs://newage-test-bucket/semc160d/sys020@wo'
    semc160dEnv['FIO-SYS021'] = 'gs://newage-test-bucket/semc160d/sys021@wo'
    semc160dEnv['FIO-SYS022'] = 'gs://newage-test-bucket/semc160d/sys022@wo'
    semc160dCmd = "ls -l /"
    semc160d = crtK8sPodOperator('semc160d', semc160dEnv, semc160dCmd, "/home")
    # [END composer_kubernetespodoperator_minconfig_airflow_1]
    semc160d >> semc152d >> semc153d 
# [END composer_kubernetespodoperator_airflow_1]
